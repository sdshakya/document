for DB in `cat ListOfDatabases.txt`
do
    mysql -uroot -p<password> -e "drop database ${DB}"
done
wait

