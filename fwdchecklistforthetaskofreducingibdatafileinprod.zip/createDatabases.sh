for DB in `cat ListOfDatabases.txt`
do
    mysql -uroot -p<password> -e "create database ${DB}"
done
wait
